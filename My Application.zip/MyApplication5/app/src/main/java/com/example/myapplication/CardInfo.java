package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.Date;

public class CardInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_info);

        final EditText date, ccNumber, cVV;


        Button submit;

        submit = findViewById(R.id.submitCC);

        date = findViewById(R.id.expDate);
        ccNumber = findViewById(R.id.CCnumber);
        cVV = findViewById(R.id.CVV);


        //Executes when submit button is clicked
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Retrieves data from the CardInfo view
                String Date = date.getText().toString();
                String Number = ccNumber.getText().toString();
                String cvNumber = cVV.getText().toString();

                //Checks to make sure a cc number is entered
                if (Number.isEmpty()) {
                    ccNumber.setError("Please enter a CC Number");
                    ccNumber.requestFocus();

                }

                //Checks to make sure a expiration date is entered
                else if(Date.isEmpty()){
                    date.setError("Please enter your expiration date");
                    date.requestFocus();
                }

                //Checks to make sure a CVV number is entered
                else if(cvNumber.isEmpty()){
                    cVV.setError("Please enter your CVV");
                    cVV.requestFocus();
                }

                //Checks to make sure the CC Number is the proper length
                else if(Number.length() > 19 || Number.length() < 16){
                    ccNumber.setError("Please check your CC number and re-enter");
                    ccNumber.requestFocus();

                }

                //Checks to make sure CV number is the proper length
                else if(cvNumber.length() > 4 || cvNumber.length() < 3){
                    cVV.setError("Please check your CVV number and re-enter");
                    cVV.requestFocus();
                }

                //Checks to make sure the exp date is the proper length
                else if(Date.length() != 7){
                    date.setError("Please enter a date in the form of mm/yyyy");
                    date.requestFocus();
                }

                //Submits the info to the database and returns back to homepage
                else{

                    //Insert code for CC info data to database
                    Intent returnHome = new Intent(CardInfo.this, HomeScreen.class);
                    startActivity(returnHome);
                }

            }
        });
    }
}