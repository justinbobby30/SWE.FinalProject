package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login extends AppCompatActivity {

    public EditText emailId, password;
    Button signIn;
    TextView signUp;
    FirebaseAuth mFireBaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mFireBaseAuth = FirebaseAuth.getInstance();
        emailId= findViewById(R.id.Email);
        password = findViewById(R.id.Password);
        signUp = findViewById(R.id.RegisterHere);
        signIn = findViewById(R.id.SignIn);

        mAuthStateListener = new FirebaseAuth.AuthStateListener() {




            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                //Retrieves current user
                FirebaseUser user = mFireBaseAuth.getCurrentUser();

                //Makes sure user exists
                if(user != null){

                    Toast.makeText(Login.this, "You are logged in :)", Toast.LENGTH_SHORT).show();

                    Intent toHome =  new Intent(Login.this, HomeScreen.class);
                    startActivity(toHome);
                }
                //Notifies user if user doesnt exist
                else{
                    Toast.makeText(Login.this, "Unsuccessful Login :(", Toast.LENGTH_SHORT).show();
                }


            }
        };

        //Executes when sign in button is clicked
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = emailId.getText().toString();
                String pass = password.getText().toString();

                //Checks to make sure email is not empty and throws an error message if it is
                if(email.isEmpty()){
                    emailId.setError("Please enter your email");
                    emailId.requestFocus();
                }
                //Checks to make sure pass is not empty and throws an error message if it is
                else if(pass.isEmpty()){
                    password.setError("Please enter your password");
                    password.requestFocus();
                }

                //Notifies user if both fields are empty
                else if(pass.isEmpty() && email.isEmpty()){
                    Toast.makeText(Login.this,"Fields are Empty", Toast.LENGTH_SHORT).show();

                }

                //Executes and logs user in if both fields are entered
                else if(!(pass.isEmpty() && email.isEmpty())){
                    mFireBaseAuth.signInWithEmailAndPassword(email, pass).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //Executes if the log in is not successful
                            if(!task.isSuccessful()){
                                Toast.makeText(Login.this,"Login Error, please try again!", Toast.LENGTH_SHORT).show();
                            }
                            //Sings user in and sends user to home screen
                            else{
                                Intent toHome = new Intent(Login.this, HomeScreen.class);
                                startActivity(toHome);

                            }
                        }
                    });

                }
                else{
                    Toast.makeText(Login.this,"Sorry, an error has occurred", Toast.LENGTH_SHORT).show();
                }

            }
        });

        //Sends user to sign up view when clicked
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toMain = new Intent(Login.this, MainActivity.class);
                startActivity(toMain);
            }
        });
    }

    @Override
    protected void onStart(){
        super.onStart();
        mFireBaseAuth.addAuthStateListener(mAuthStateListener);
    }
}
