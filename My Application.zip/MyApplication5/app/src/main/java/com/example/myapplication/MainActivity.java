package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;

public class MainActivity extends AppCompatActivity {

    public EditText emailId, password;
    Button signUp;
    TextView signIn;
    FirebaseAuth mFireBaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFireBaseAuth = FirebaseAuth.getInstance();
        emailId= findViewById(R.id.Email);
        password = findViewById(R.id.Password);
        signUp = findViewById(R.id.RegisterButton);
        signIn = findViewById(R.id.SignIn);

        //Executes when signup button is clicked
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = emailId.getText().toString();
                String pass = password.getText().toString();

                //Checks to make sure email is not empty and throws an error message if it is
                if(email.isEmpty()){
                    emailId.setError("Please enter your email");
                    emailId.requestFocus();
                }
                //Checks to make sure email is not empty and notifies user if true
                else if(pass.isEmpty()){
                    password.setError("Please enter your password");
                    password.requestFocus();
                }

                //Checks to make sure both fields are not empty and notifies user if they are
                else if(pass.isEmpty() && email.isEmpty()){
                    Toast.makeText(MainActivity.this,"Fields are Empty", Toast.LENGTH_SHORT).show();

                }

                //Executes if both fields are not empty
                else if(!(pass.isEmpty() && email.isEmpty())){

                    //Sends email and password info to google Firebase authenticator
                    mFireBaseAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            //Notifies if user sign up is unsuccessful
                            if(!task.isSuccessful()){
                                Toast.makeText(MainActivity.this,"Sign up unsuccessful, please try again", Toast.LENGTH_SHORT).show();
                            }

                            //If user sign up is successful logs user in and sends user to homepage
                            else{
                                startActivity(new Intent(MainActivity.this, HomeScreen.class));
                            }
                        }
                    });

                }

                //Catch all error message
                else{
                    Toast.makeText(MainActivity.this,"Sorry, an error has occurred", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Sends user to sign in view if clicked
        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toLogIn = new Intent(MainActivity.this, Login.class);
                startActivity(toLogIn);
            }
        });
    }

}
