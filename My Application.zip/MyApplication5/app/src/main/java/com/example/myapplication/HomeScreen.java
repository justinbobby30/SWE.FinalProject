package com.example.myapplication;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class HomeScreen extends AppCompatActivity {

    Button logOut, cardInfo, bankInfo;
    FirebaseAuth logoff;
    private FirebaseAuth.AuthStateListener logofflistener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        logOut = findViewById(R.id.LogOut);
        cardInfo = findViewById(R.id.CreditDebit);
        bankInfo = findViewById(R.id.BankAccount);

        //Logs out the user and returns you to log in screen when the user clicks the log out button
        logOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                Intent toMain = new Intent(HomeScreen.this, MainActivity.class);
                startActivity(toMain);
            }
        });

        //Sends user to card info view to enter card info when user clicks card/debit button
        cardInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toCardInfo = new Intent(HomeScreen.this, CardInfo.class);
                startActivity(toCardInfo);
            }
        });

        //Sends user to bank info view to enter bank account info when user clicks bank button
        bankInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toBankInfo = new Intent(HomeScreen.this, BankInfo.class);
                startActivity((toBankInfo));
            }
        });
    }
}
