package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class BankInfo extends AppCompatActivity {

    TextView routing, accNumber;
    Button submitTwo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bank_info);

        //Executes when the submit button is clicked
        submitTwo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String routnum = routing.getText().toString();
                String accnume = accNumber.getText().toString();

                //Checks to make sure a routing number is entered and shoots an message error if true
                if(routnum.isEmpty()){
                    routing.setError("Please enter a routing number");
                    routing.requestFocus();
                }

                //Checks to make sure a account number is entered and shoots an error message if true
                else if(accnume.isEmpty()){
                    accNumber.setError("Please enter a account number");
                    accNumber.requestFocus();
                }

                //Checks the length of the account number and notifies user if not proper length
                else if(accnume.length() > 12 || accnume.length() < 10){
                    accNumber.setError("Please check your account number and re-enter");
                    accNumber.requestFocus();
                }

                //Checks the length of the routing number and notifies uer if not proper length
                else if(routnum.length() != 9){
                    routing.setError("Please check your routing number an re-enter");
                    routing.requestFocus();
                }

                //Sends bank account info to database and sends user back to homepage
                else{

                    //insert code to send bank account info to database
                    Intent backHome = new Intent(BankInfo.this, HomeScreen.class);
                    startActivity(backHome);
                }
            }
        });
    }
}
